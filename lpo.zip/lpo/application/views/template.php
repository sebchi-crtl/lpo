
      <div class="content">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Request for Quote</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Purchase Order</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Pay Purchase Order</a>
          </li>
        </ul>
        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <div class="card card-user d-flex">
              <div class="card-header">
                <h5 class="card-title">RFQ</h5>
              </div>
              <div class="card-body">
                <form>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Company (disabled)</label>
                        <input type="text" class="form-control" disabled="" placeholder="Company" value="Creative Code Inc.">
                      </div>
                    </div>
                    <div class="col-md-6 pt-1 pr-3">
                      <div class="form-group">
                        <label>Item</label>
                        <input type="text" class="form-control" placeholder="Item" namm=Item >
                      </div>
                    </div>
                    <div class="col-md-12 px-3">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <textarea name="description" class="form-control" placeholder="Item Description" id="" cols="30" rows="10"></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label>Manufacturer</label>
                        <input type="text" class="form-control" placeholder="Dangote">
                      </div>
                    </div>
                    <div class="col-md-5 py-1 pl-5">
                      <div class="form-group">
                      <div class="form-check form-check-inline pb-1">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                        <label class="form-check-label" for="inlineRadio1">Specific Manufacturer</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                        <label class="form-check-label" for="inlineRadio2">Non-Specific Manufacturer</label>
                      </div>
                      </div>
                    </div>
                    <div class="col-md-3 ">
                      <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" class="form-control" placeholder="Qty">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Create</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <div class="card card-user d-flex">
              <div class="card-header">
                <h5 class="card-title">PO</h5>
              </div>
              <div class="card-body">
                <form>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Company (disabled)</label>
                        <input type="text" class="form-control" disabled="" placeholder="Company" value="Creative Code Inc.">
                      </div>
                    </div>
                    <div class="col-md-6 pt-1 pr-3">
                      <div class="form-group">
                        <label>Item</label>
                        <input type="text" class="form-control" placeholder="Item" namm=Item >
                      </div>
                    </div>
                    <div class="col-md-12 px-3">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <textarea name="description" class="form-control" placeholder="Item Description" id="" cols="30" rows="10"></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label>Manufacturer</label>
                        <input type="text" class="form-control" placeholder="Dangote">
                      </div>
                    </div>
                    <div class="col-md-5 py-1 pl-5">
                      <div class="form-group">
                      <div class="form-check form-check-inline pb-1">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                        <label class="form-check-label" for="inlineRadio1">Specific Manufacturer</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                        <label class="form-check-label" for="inlineRadio2">Non-Specific Manufacturer</label>
                      </div>
                      </div>
                    </div>
                    <div class="col-md-3 ">
                      <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" class="form-control" placeholder="Qty">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                      <button type="submit" class="btn btn-primary btn-round">Create</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
        </div>
      </div>
