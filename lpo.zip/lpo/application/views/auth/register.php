
<!doctype html>
<html lang="en">
    <head>
    <title>
        Register/Login
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700|Raleway:300,600" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <!-- CSS Files -->
    <link href="<?php echo base_url('assets/main/style.css') ?>" rel="stylesheet" />
    </head>
    <body>
        <div class="container">
            <section id="formHolder">

                <div class="row">

                    <!-- Brand Box -->
                    <div class="col-sm-6 brand">
                        <a href="#" class="logo"><img src="<?php echo base_url('assets/img/cropped-cropped-LOGO.png') ?>" width=50% alt=""> </a>

                        <div class="heading">
                        <h2>sales 366</h2>
                        <p>Your Right Choice</p>
                        </div>

                        <div class="success-msg">
                        <p>Great! You are one of our members now</p>
                        <a href="#" class="profile">Your Profile</a>
                        </div>
                    </div>


                    <!-- Form Box -->
                    <div class="col-sm-6 form">

                        <!-- Login Form -->
                        <div class="login form-peice switched">
                        <form class="login-form" action="#" method="post">
                            <div class="form-group">
                                <label for="loginemail">Email Adderss</label>
                                <input type="email" name="loginemail" id="loginemail" required>
                            </div>

                            <div class="form-group">
                                <label for="loginPassword">Password</label>
                                <input type="password" name="loginPassword" id="loginPassword" required>
                            </div>

                            <div class="CTA">
                                <input type="submit" value="Login">
                                <a href="#" class="switch">I'm New</a>
                            </div>
                        </form>
                        </div><!-- End Login Form -->


                        <!-- Signup Form -->
                        <div class="signup form-peice">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('register'); ?>
                                <div class="scroll">
                                    <div class="form-group">
                                        <label for="name">Full Name</label>
                                        <input type="text" name="username" id="name" class="name">
                                        <span class="error"></span>
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email Adderss</label>
                                        <input type="email" name="emailAdress" id="email" class="email">
                                        <span class="error"></span>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="phone">Phone Number - <small>Optional</small></label>
                                                <input type="text" name="phone" id="phone">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="position">Office Position - <small>Optional</small></label>
                                                <input type="text" name="phone" id="position">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="password">Password</label>
                                                <input type="password" name="password" id="password" class="pass">
                                                <span class="error"></span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="passwordCon">Confirm Password</label>
                                                <input type="password" name="passwordCon" id="passwordCon" class="passConfirm">
                                                <span class="error"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="gender-details">
                                    <input type="radio" name="gender" id="dot-1" >
                                    <input type="radio" name="gender" id="dot-2" >
                                    <input type="radio" name="gender" id="dot-3" >
                                    <span class="gender-title">specify</span>
                                    <div class="category">
                                        <label for="dot-1">
                                            <span class="dot one"></span>
                                            <span class="gender">vendors</span>
                                        </label>
                                        <label for="dot-2">
                                            <span class="dot two"></span>
                                            <span class="gender">purchasers</span>
                                        </label>
                                        <label for="dot-3">
                                            <span class="dot three"></span>
                                            <span class="gender">agree to terms</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="CTA">
                                    <input type="submit" value="Signup Now" id="submit">
                                    <a href="#" class="switch">I have an account</a>
                                </div>
                            </form>
                        </div><!-- End Signup Form -->
                    </div>
                </div>

            </section>
            <!-- <footer>
                <p>
                    Form made by: <a href="http://mohmdhasan.tk" target="_blank">Mohmdhasan.tk</a>
                </p>
            </footer> -->
        </div>
        
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <script type="text/javascript">
            /*global $, document, window, setTimeout, navigator, console, location*/
            $(document).ready(function(){
                'use strict';

                var usernameError = true,
                    emailError    = true,
                    passwordError = true,
                    passConfirm   = true;

                // Detect browser for css purpose
                if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                    $('.form form label').addClass('fontSwitch');
                }

                // Label effect
                $('input').focus(function() {

                    $(this).siblings('label').addClass('active');
                });

                // Form validation
                $('input').blur(function () {

                    // User Name
                    if ($(this).hasClass('name')) {
                        if ($(this).val().length === 0) {
                            $(this).siblings('span.error').text('Please type your full name').fadeIn().parent('.form-group').addClass('hasError');
                            usernameError = true;
                        } else if ($(this).val().length > 1 && $(this).val().length <= 6) {
                            $(this).siblings('span.error').text('Please type at least 6 characters').fadeIn().parent('.form-group').addClass('hasError');
                            usernameError = true;
                        } else {
                            $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                            usernameError = false;
                        }
                    }
                    // Email
                    if ($(this).hasClass('email')) {
                        if ($(this).val().length == '') {
                            $(this).siblings('span.error').text('Please type your email address').fadeIn().parent('.form-group').addClass('hasError');
                            emailError = true;
                        } else {
                            $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                            emailError = false;
                        }
                    }

                    // PassWord
                    if ($(this).hasClass('pass')) {
                        if ($(this).val().length < 8) {
                            $(this).siblings('span.error').text('Please type at least 8 charcters').fadeIn().parent('.form-group').addClass('hasError');
                            passwordError = true;
                        } else {
                            $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                            passwordError = false;
                        }
                    }

                    // PassWord confirmation
                    if ($('.pass').val() !== $('.passConfirm').val()) {
                        $('.passConfirm').siblings('.error').text('Passwords don\'t match').fadeIn().parent('.form-group').addClass('hasError');
                        passConfirm = false;
                    } else {
                        $('.passConfirm').siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                        passConfirm = false;
                    }

                    // label effect
                    if ($(this).val().length > 0) {
                        $(this).siblings('label').addClass('active');
                    } else {
                        $(this).siblings('label').removeClass('active');
                    }
                });


                // form switch
                $('a.switch').click(function(e){
                    $(this).toggleClass('active');
                    e.preventDefault();

                    if ($('a.switch').hasClass('active')) {
                        $(this).parents('.form-peice').addClass('switched').siblings('.form-peice').removeClass('switched');
                    } else {
                        $(this).parents('.form-peice').removeClass('switched').siblings('.form-peice').addClass('switched');
                    }
                });


                // Form submit
                $('form.signup-form').submit(function(event) {
                    event.preventDefault();

                    if (usernameError == true || emailError == true || passwordError == true || passConfirm == true) {
                        $('.name, .email, .pass, .passConfirm').blur();
                    } else {
                        $('.signup, .login').addClass('switched');

                        setTimeout(function () { $('.signup, .login').hide(); }, 700);
                        setTimeout(function () { $('.brand').addClass('active'); }, 300);
                        setTimeout(function () { $('.heading').addClass('active'); }, 600);
                        setTimeout(function () { $('.success-msg p').addClass('active'); }, 900);
                        setTimeout(function () { $('.success-msg a').addClass('active'); }, 1050);
                        setTimeout(function () { $('.form').hide(); }, 700);
                    }
                });

                // Reload page
                $('a.profile').on('click', function () {
                    location.reload(true);
                });
            });

        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    </body>
</html>
